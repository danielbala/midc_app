package com.bbdesign.MIDC;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;

public class BTDiscovery implements DiscoveryListener, Runnable{
	
	private Object 			_lock 				= new Object(); //object to wait on for the bt callback methods
	private boolean 		_running 			= true;			//setting to false should properly end all loops and threads
	private boolean 		_deviceDiscovered 	= false;		//whether we have discovered a device that Courier can talk to
	private RemoteDevice 	_remoteDevice 		= null;			//reference to the device which we use for comms
	private List<String> 	_deviceNames 		= new ArrayList<String>(); //holds all of the possible device names that we can talk to
	private String			_url				= null;			//the bluetooth service url. This will also get written to the UserParms class to make it accessible
	
	//retrieve the acceptable device names to connect to from the user parms
	BTDiscovery(){
		String[] tmp = UserParms.getDeviceNames();
		for(int i=0;i<tmp.length;i++){
	    	_deviceNames.add(tmp[i].toUpperCase()); 
	    }
	}
	
	//----------Runnable Interface ----------
	//first find devices, and wait till it is done.
	//if we found a suitable device, discover its services and wait.
	//when that is done, bail and finish the thread
	
	public void run() {
		int attempts = 0;
		
		while(_running && attempts++ < 10){
			try {
				populateLocalDevices();
				synchronized(_lock){
					_lock.wait();
				}
				
				if(_deviceDiscovered){
					populateServices();
					synchronized(_lock){
						_lock.wait();
					}
					_running = false;
				}
				
			} catch (BluetoothStateException bse){
				System.out.println("BTOFF");
				this.shutDown();
				
			} catch (IOException e) {
				e.printStackTrace();
				this.shutDown();
			} catch (InterruptedException e) {
				e.printStackTrace();
				this.shutDown();
			}
		}
	}
	
	//----------DiscoveryListener interface ----------
	//this method will be called repeatedly for each bluetooth device found.
	//we need to check to see whether any device has an acceptable name. 
	
	public void deviceDiscovered(RemoteDevice btDevice, DeviceClass deviceClass) {
		String friendlyName;
		try{
    		friendlyName = btDevice.getFriendlyName(false);
    		System.out.println(friendlyName);

		 	if( _deviceNames.contains( friendlyName.toUpperCase() ) ){ 
		 		_deviceDiscovered = true;
		 		_remoteDevice = btDevice;
		 		UserParms.setRemoteDevice(_remoteDevice);
		 	} 
    	}
    	catch(IOException ioe){
    		_running = false;
    		System.err.print(ioe.toString());
    	}
	}
	//this method will be called when all bluetooth devices have been discovered.
	//at this point release the thread above, and if we have found a suitable device, discover the services on that device.
	
	public void inquiryCompleted(int discoveryType) {
		switch (discoveryType) {
	        case DiscoveryListener.INQUIRY_COMPLETED :
	            System.out.println("INQUIRY_COMPLETED");
	        	if(!_deviceDiscovered){
	        		System.out.println("NOTFOUND");	
	        	}
	           break;
	        case DiscoveryListener.INQUIRY_TERMINATED :
	            System.out.println("INQUIRY_TERMINATED");
	            break;
	        case DiscoveryListener.INQUIRY_ERROR :
	            System.out.println("INQUIRY_ERROR");
	            break;
	        default :
	            System.out.println("Unknown Response Code");
	            break;
	    }
	    synchronized(_lock){
	    	_lock.notify();
	    }
	}

	
	public void servicesDiscovered(int arg0, ServiceRecord[] servRecord) {
		System.out.println("Service count: " + servRecord.length);
    	
    	for(int i=0;i<servRecord.length;i++){
    		String tmpUrl = servRecord[0].getConnectionURL(0,false);
    		tmpUrl = tmpUrl.replace("btspp://", "");
    		String[] parseUrl = tmpUrl.split("[;]");
    		_url=parseUrl[0];
    		UserParms.setUrl(_url);
    		System.out.println(_url);
    	}
	}
	
	
	public void serviceSearchCompleted(int arg0, int arg1) {
		synchronized(_lock){
            _lock.notify();
        }
	}

	//----------user defined methods----------
	//this will cause deviceDiscovered to be repeatedly called until all bt devices are discovered
	public void populateLocalDevices() throws IOException,javax.bluetooth.BluetoothStateException{
		LocalDevice.getLocalDevice().getDiscoveryAgent().startInquiry( DiscoveryAgent.GIAC, this);
	}
	
	//this will cause servicesDiscovered to be repeatedly called until all services on a given bt device are found
	public void populateServices(){
		System.out.println("populating services");
		UUID[] uuidSet = new UUID[1];
		uuidSet[0]=new UUID(0x1101);
		try{
			LocalDevice.getLocalDevice().getDiscoveryAgent().searchServices( null, uuidSet, _remoteDevice , this);
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
	}
	
	public void shutDown(){
		_running = false;
	}
	
}
