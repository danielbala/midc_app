package com.bbdesign.MIDC;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//accept parameters
		if(args.length != 4){
			System.out.println("Courier requires 4 parameters: Address BodyWeight DeviceNames UOM(0=metric,1=standard). Exiting Application.");
			System.exit(0);
		}
		UserParms.setUrl(args[0]);
		
		UserParms.setBodyWeight(args[1]);
		UserParms.setDeviceNames (args[2]);
		UserParms.setUOM(args[3]);
		
		//kick off main process thread.
		//this thread will kick off and control all other processes and threads
		
		Thread mainThread = new Thread( new CourierService() );
		mainThread.start();
		
		try
		{
			mainThread.join();
		}
		catch(InterruptedException ie){
			
		}
		System.out.println("main exiting");
	}

}
