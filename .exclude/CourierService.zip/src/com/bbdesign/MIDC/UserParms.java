package com.bbdesign.MIDC;

import javax.bluetooth.RemoteDevice;

public class UserParms {
	//this class is populated with all data when the app starts so it is available to all classes.
	
	private static int 			_bodyWeight 	= 0;
	private static String 		_url 			= "";
	private static String 		_deviceNames	= "";
	private static int 			_uom 			= -1; //0=metric,1=standard
	private static RemoteDevice _remoteDevice 	= null;
	
	//---bodyWeight property---
	public static void setBodyWeight(String val){
		if(!val.equalsIgnoreCase("empty")){
			_bodyWeight = Integer.parseInt(val);
		}
	}
	public static int getBodyWeight(){
		return _bodyWeight;
	}
	
	//---ur propertyl---
	public static void setUrl(String val){
		if(!val.equalsIgnoreCase("empty")){
			_url = val;
		}
	}
	public static String getUrl(){
		return _url;
	}
	
	//---deviceNames---
	public static void setDeviceNames(String val){
		_deviceNames = val;
	}
	public static String[] getDeviceNames(){
		String[] tmp = _deviceNames.split("[,]");
		return tmp;
	}
	
	//---UOM---
	public static void setUOM(String val){
		_uom = Integer.parseInt(val);
	}
	
	public static int getUOM(){
		return _uom;
	}
	
	//-----remote device-----
	public static void setRemoteDevice(RemoteDevice val){
		_remoteDevice = val;
	}
	public static RemoteDevice getRemoteDevice(){
		return _remoteDevice;
	}
}
