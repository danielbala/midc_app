package com.bbdesign.MIDC.Input;

import java.util.EventObject;

public class InputReceivedEvent extends EventObject{
	
	
	//this event will be raised whenever the application receives a message through the std input.
	private String _message;
	
	public InputReceivedEvent(Object source, String message){
		super(source);
		
		_message = message;
	}
	public String getMessage(){
		return _message;
	}
}
