package com.bbdesign.MIDC.Input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class InputStreamHandler implements Runnable{

	private boolean 				_running  = true; //set to false to kill thread
	private InputReceivedListener 	_listener = null; //reference to the object that will receive input when detected
	
	//-------------Runnable interface--------------------
	
	public void run() {

		BufferedReader br = new BufferedReader( new InputStreamReader(System.in) );

	    String input = null;
	    
		while(_running){
			try {
				input = br.readLine();
				fireEvent(input);
			} catch (IOException e) {
				e.printStackTrace();
				_running = false;

			}
		}
	}
	
	//-------------Input Received interface--------------------
	
	public synchronized void addEventListener(InputReceivedListener listener){
		_listener = listener;
	}
	private void fireEvent(String message){
		_listener.InputReceived( new InputReceivedEvent(this,message) );
	}
	
	//-------------user defined methods--------------------
	
	public void shutDown(){
		_running = false;
	}
	
}
