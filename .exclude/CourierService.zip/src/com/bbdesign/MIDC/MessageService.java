package com.bbdesign.MIDC;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.bluetooth.RemoteDevice;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

import com.bbdesign.MIDC.Messages.MessageCodes;
import com.intel.bluetooth.RemoteDeviceHelper;

public class MessageService implements Runnable{
	
	private 	boolean 		_running 			= true; //am I running?
	private		boolean			_hasWorkedOut		= false; //flag used to know if the user has gone into a workout state, so that if we go to idle again, we send an "S" to MIDC which will kill our app.
	
	private 	OutputStream 	_outStream			= null; //output bytestream to bluetooth device
	private 	InputStream 	_inStream 			= null; //input bytestream from bluetooth device
	private 	byte[] 			_requestBytes  		= new byte[5]; //local outgoin
	private 	byte[] 			_responseBytes 		= new byte[6];
	private		boolean			_error				= false;
	private		Message			_msg				= null;
	private		boolean			_initializing		= false;
	private 	boolean			_shutdown			= false;
	
	MessageService(){
		startUp();
	}
	
	private void startUp(){
		String urlFormat = "btspp://%s;authenticate=false;encrypt=false;master=false";
		StreamConnection streamCon;
		RemoteDevice rd = UserParms.getRemoteDevice();
		String url;
		//private 	String 			_url				= "";
		
		try{
			url = String.format(urlFormat,UserParms.getUrl() );
			System.out.println("Trying to connect." + url);
			
			streamCon=(StreamConnection)Connector.open(url);
			System.out.println("opened.");
			/* why was this here? we get the remote device when we discover the device
			 */
			
			if(rd == null){ //if we do not go through the discovery process, the remote device will be null. get it from the connection object.
				rd = RemoteDevice.getRemoteDevice(streamCon);
			}
			System.out.println("got device.");
			
			boolean authenticated  = RemoteDeviceHelper.authenticate(rd,"0000");
			
//RemoteDeviceHelper.			
			System.out.println("authenticated: " + authenticated);
			
			_outStream = streamCon.openDataOutputStream();
			_inStream  = streamCon.openInputStream();
			_msg = new Message();
			_msg.address = UserParms.getUrl();
			
			System.out.println("CONNECTED|" + UserParms.getUrl() + "|" + rd.getFriendlyName(false));
			//send initial messages
			
			//get device id
			sendMessage(MessageCodes.MSG_DEVICE_ID);
			
			//set the body weight
			byte[] weightBytes = toBytes( UserParms.getBodyWeight() );
			sendMessage(MessageCodes.MSG_SET_WEIGHT,weightBytes[2],weightBytes[3]);
			
			//set the uom
			
			sendMessage(MessageCodes.MSG_SET_UOM, (UserParms.getUOM() == 0) ? (byte)0xAA : (byte)0xFF );
			
			//connected = true;
		}
		catch(javax.bluetooth.BluetoothStateException bse){
			System.out.println(bse.toString());
			System.out.println("BTOFF");
			_running = false;
		}
		catch(javax.bluetooth.BluetoothConnectionException bce){
			System.out.println(bce.toString());
			System.out.println("NOTFOUND");
			_running = false;
		}
		catch(IOException e){
			//fireErrorEvent();
			System.out.println("ioexception");
			System.out.println(e.toString());
			_running = false;
		}
		catch(Exception e){
			//fireErrorEvent();
			_error = true;
			System.out.println("exception<br>");
			e.printStackTrace();
			_running = false;
		}// end try
	}
	
	public void run(){
		long start, end, timeToWait;
		
		while(_running){
			_msg.reset();
			
			start = System.currentTimeMillis();
			
			//if (_msg.devicetype.equals("T")){
				sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_STEP);
			//}
			//else if(_msg.devicetype.equals("B")){
			//	sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_RPM);
			//}
			
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_CALORIES);
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_DISTANCE);
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_TIME);
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_TREADBELT_SPEED);
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_UOM);
			sendMessage(MessageCodes.MSG_VARIABLE,MessageCodes.MSG_VARIABLE_STATUS);
			
			end = System.currentTimeMillis();
			
			timeToWait = 1000 - (end - start);
			//System.out.println(timeToWait);
			
			if(timeToWait < 0)
				timeToWait = 0;
			
			//System.out.println(end - start);
			
			try {
				Thread.sleep(timeToWait);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			System.out.println( _msg.toString() );
		}
	}
	
	
	public void shutDown(){
		_running = false;
	}
	
	private void sendMessage(byte b1){
		sendMessage(b1,MessageCodes.EMPTY);
	}
	
	private void sendMessage(byte b1, byte b2){
		sendMessage(b1, b2, MessageCodes.EMPTY);
	}
	private void sendMessage(byte b1, byte b2, byte b3){
		clearRequest();
		_requestBytes[0] = b1;
		_requestBytes[1] = b2;
		_requestBytes[2] = b3;
		pushByteBuffer();
		waitForResponse();
		processResponse();
	}
	private void pushByteBuffer(){
		try{
			//readyToSend = false;
			//printByteArray(requestBytes);
			_outStream.write(_requestBytes);
			_outStream.flush();
		}
		catch(IOException ioe){
			System.out.println(ioe.toString());
			//fireErrorEvent();
			//stopListening();
		}
	}
	
	private void waitForResponse(){
		while(true){
			
			try {
				if(_inStream.available() >= 6){
						clearResponse();
						_inStream.read(_responseBytes);
						break;
				}
				else{
					Thread.sleep(10);
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	private void clearResponse(){
		for(int i = 0; i < _responseBytes.length-1; i++){
			_responseBytes[i] = MessageCodes.EMPTY;
		}
	}
	
	private void clearRequest(){
		for(int i = 0; i < _requestBytes.length-1; i++){
			_requestBytes[i] = MessageCodes.EMPTY;
		}
	}
	
	private void processResponse(){
		 switch(_responseBytes[0]){
		    case MessageCodes.MSG_VARIABLE: 
		    	switch(_requestBytes[1]){
		    	    case MessageCodes.MSG_VARIABLE_UOM:      
		    	    	_msg.uom = (_responseBytes[2] == MessageCodes.MSG_VARIABLE_UOM_METRIC ? 0 : 1);
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_STEP:     
		    	    	_msg.steps = (this.mergeBytes(_responseBytes[2], _responseBytes[3]));
		    	    	/*if( _initializing && _msg.steps > 0 ){
		    	    		_initializing = false;
		    	    	}
		    	    	else if (!_initializing && _msg.steps == 0 ){
		    	    		_shutdown = true;
		    	    	}*/
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_RPM:
		    	    	printByteArray(_responseBytes);
		    	    	_msg.rpm = (this.mergeBytes(_responseBytes[2], _responseBytes[3]));
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_CALORIES: 
		    	    	_msg.calories= (this.mergeBytes(_responseBytes[2], _responseBytes[3]));
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_DISTANCE: 
		    	    	_msg.distance_whole =    (int)_responseBytes[2];					    
		    	    	_msg.distance_fraction = (int)_responseBytes[3];
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_TIME:     
		    	    	_msg.time_hour =   (int)_responseBytes[2];
		    	    	_msg.time_minute = (int)_responseBytes[3];
		    	    	_msg.time_second = (int)_responseBytes[4];
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_STATUS:
		    	    	_msg.flag = "";
		    	    	switch(_responseBytes[2]){
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_EDIT: 
		    	    			_msg.status = "edit"; 
		    	    			break;
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_IDLE:	
		    	    			_msg.status = "idle"; 
		    	    			if (_hasWorkedOut) _msg.flag = "S";
		    	    			break;
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_KEY:	
		    	    			_msg.status = "key"; 
		    	    			break;
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_PAUSE:
		    	    			_msg.flag = "P";
		    	    			_msg.status = "pause"; 
		    	    			break;
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_RUN:	
		    	    			_msg.status = "run"; 
		    	    			_hasWorkedOut = true;
		    	    			break;
		    	    		case MessageCodes.MSG_VARIABLE_STATUS_ERR:	
		    	    			_msg.status = "err"; 
		    	    			break;
		    	    		default: _msg.status = "UNK:" + _responseBytes[2];
		    	    	};
		    	    	
		    	    	break;
		    	    case MessageCodes.MSG_VARIABLE_TREADBELT_SPEED:   
		    	    	_msg.treadbelt_speed_whole = (int) _responseBytes[2] ;
		    	    	_msg.treadbelt_speed_fraction = (int) _responseBytes[3] ;
		    	    	/*if(_msg.treadbelt_speed_whole == 0 && _msg.treadbelt_speed_fraction == 0 ){
		    	    		_msg.flag = "P";
		    	    	}
		    	    	else{
		    	    		_msg.flag = "";
		    	    	}*/
		    	    	break;
		    	};
		    	break;
		    case MessageCodes.MSG_DEVICE_ID:
		    	switch(_responseBytes[2]){
		    	   case MessageCodes.MSG_DEVICE_ID_TREADMILL:  _msg.devicetype = "T"; break;
		    	   case MessageCodes.MSG_DEVICE_ID_BIKE:       _msg.devicetype = "B"; break;
		    	   case MessageCodes.MSG_DEVICE_ID_ELLIPTICAL: _msg.devicetype = "E"; break;
		    	   case MessageCodes.MSG_DEVICE_ID_STEPPER:    _msg.devicetype = "S"; break;
		    	};
		    	break;
		    case MessageCodes.MSG_SET_WEIGHT:
		    case MessageCodes.MSG_ENGAGE_EX_CTL:
		    case MessageCodes.MSG_FIRMWARE:
		    case MessageCodes.MSG_RESET_ALL:
		    	if(_responseBytes[1] == MessageCodes.STATUS_OK)
		    		System.out.println(String.format("%02X ", _responseBytes[0]) + "successfully written.");
		    	else
		    		System.out.println(String.format("%02X ", _responseBytes[0]) + " set failure");
		        break;
		    	//requestBytes[0] = MSG_DEVICE_ID
		 };
		 //readyToSend = true;
	 }
	
	public int mergeBytes(byte b1, byte b2){
		return (int)(b1 << 8) | (b2 & 0xFF);
	}
	
	public byte[] toBytes(int i)
	{
	  byte[] result = new byte[4];

	  result[0] = (byte) (i >> 24);
	  result[1] = (byte) (i >> 16);
	  result[2] = (byte) (i >> 8);
	  result[3] = (byte) (i /*>> 0*/);

	  return result;
	}

	private void printByteArray(byte[] bytes){
		
		String sOutput = new String(bytes);
		StringBuilder sb = new StringBuilder();
		
	    for (byte b : bytes) {
	        sb.append(String.format("%02X ", b));
	    }
	    System.out.println(sb.toString());
	   
	    System.out.println();
	    

	}

}
//this is a class designed to hold all of the information for one message.
//it should get cleared out between uses.
class Message{
	private String _messageFormat = "{ \"address\": \"%s\", \"devicetype\": \"%s\", \"flag\": \"%s\", \"status\": \"%s\", \"uom\": %d, \"steps\": %d, \"rpm\": %d, \"calories\": %d, \"speed\": { \"whole\": %d, \"fraction\": %d   }, \"distance\": { \"whole\": %d, \"fraction\": %d   },\"time\": { \"hour\": %d, \"minute\": %d, \"second\": %d  }}";
	public String address;
	public String devicetype 			= "";
	
	public String status 				= "";
	public String flag 					= "";
	public int uom 						= -1;
	public int steps 					= -1;
	public int rpm 						= -1;
	public int calories 				= -1;
	public int distance_whole 			= -1;
	public int distance_fraction 		= -1;
	public int time_hour 				= -1;
	public int time_minute 				= -1;
	public int time_second 				= -1;
	public int treadbelt_speed_whole 	= -1;
	public int treadbelt_speed_fraction = -1;
	
	public String toString(){
		return String.format(_messageFormat
				,address 
				,devicetype
				,flag
				,status
				,uom
				,steps
				,rpm
				,calories
				,treadbelt_speed_whole
				,treadbelt_speed_fraction
				,distance_whole
				,distance_fraction
				,time_hour
				,time_minute
				,time_second
				);
	}
	
	public void reset(){
		uom = -1;
		steps = -1;
		calories = -1;
		distance_whole = -1;
		distance_fraction = -1;
		time_hour = -1;
		time_minute = -1;
		time_second = -1;
		treadbelt_speed_whole = -1;
		treadbelt_speed_fraction = -1;
	}
	
}
