package com.bbdesign.MIDC;

import com.bbdesign.MIDC.Input.*;


public class CourierService implements Runnable, InputReceivedListener {
	private InputStreamHandler 	_inputHandler;
	private boolean 			_running = true;
	private MessageService		_msgService = null;
	
	public CourierService(){
		startUp();
	}
	
	private void startUp(){
		_inputHandler = new InputStreamHandler();
		_inputHandler.addEventListener(this);
		
		Thread inputThread= new Thread(_inputHandler);
		inputThread.start();
		
	}
	public void run() {
		//if address is empty, search for a suitable device
		
		if(UserParms.getUrl().equals("")){
			BTDiscovery btd = new BTDiscovery();
			Thread t = new Thread(btd);
			t.run();
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		//if(UserParms.getRemoteDevice() != null){
		_msgService = new MessageService();
		
		Thread t1 = new Thread(_msgService);
		t1.run();
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//}
		/*
		while(_running){
			try {
			Thread.sleep(5000);
			System.out.println("running");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		System.out.println("Courier Service Thread done");
	}
	
//----------InputReceivedListener----------
	
	
	public void InputReceived(InputReceivedEvent evt) {
		// TODO Auto-generated method stub
		String msg = evt.getMessage();
		
		System.out.println( msg );
		if(msg.equals("stop")){
			_inputHandler.shutDown();
			_running = false;
			if(_msgService != null){
				_msgService.shutDown();
			}
		}
	}
}
