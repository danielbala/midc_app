package com.bbdesign.MIDC.Input;



public interface InputReceivedListener {
	public void InputReceived(InputReceivedEvent evt);
}

