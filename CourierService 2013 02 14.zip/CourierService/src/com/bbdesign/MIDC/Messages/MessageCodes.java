package com.bbdesign.MIDC.Messages;

public class MessageCodes {
	public static final byte EMPTY 							= (byte) 0x00;
	public static final byte STATUS_OK 						= (byte) 0xAA;
	public static final byte STATUS_FAIL 					= (byte) 0xFF;
	public static final byte STATUS_WRONG_PARAMETER 		= (byte) 0xEE;
	
	public static final byte MSG_FIRMWARE 					= (byte) 0xC2;
	public static final byte MSG_ENGAGE_EX_CTL 				= (byte) 0x04;
	public static final byte MSG_DISENGAGE_EX_CTL 			= (byte) 0x05;
	public static final byte MSG_DEVICE_ID 					= (byte) 0x02;
	
	public static final byte MSG_DEVICE_ID_TREADMILL 		= (byte) 0x11;
	public static final byte MSG_DEVICE_ID_BIKE 			= (byte) 0x22;
	public static final byte MSG_DEVICE_ID_ELLIPTICAL 		= (byte) 0x44;
	public static final byte MSG_DEVICE_ID_STEPPER 			= (byte) 0x88;
	
	public static final byte MSG_VARIABLE 					= (byte) 0xA1;
	
	public static final byte MSG_VARIABLE_UOM 				= (byte) 0x81;
	public static final byte MSG_VARIABLE_UOM_METRIC 		= (byte) 0xAA;
	public static final byte MSG_VARIABLE_UOM_IMPERIAL 		= (byte) 0xFF;
	
	public static final byte MSG_VARIABLE_RPM				= (byte) 0x8A;
	public static final byte MSG_VARIABLE_TREADBELT_SPEED	= (byte) 0x82;
	public static final byte MSG_VARIABLE_DISTANCE 			= (byte) 0x85;
	public static final byte MSG_VARIABLE_PULSE 			= (byte) 0x86;
	public static final byte MSG_VARIABLE_CALORIES 			= (byte) 0x87;
	public static final byte MSG_VARIABLE_STEP 				= (byte) 0x88;
	public static final byte MSG_VARIABLE_TIME 				= (byte) 0x89;
	
	public static final byte MSG_VARIABLE_STATUS			= (byte) 0x91;
	public static final byte MSG_VARIABLE_STATUS_IDLE		= (byte) 0x01;
	public static final byte MSG_VARIABLE_STATUS_RUN		= (byte) 0x03;
	public static final byte MSG_VARIABLE_STATUS_PAUSE		= (byte) 0x05;
	public static final byte MSG_VARIABLE_STATUS_EDIT		= (byte) 0x09;
	public static final byte MSG_VARIABLE_STATUS_KEY		= (byte) 0x0A;
	public static final byte MSG_VARIABLE_STATUS_ERR		= (byte) 0x0F;
	
	public static final byte MSG_RESET_ALL 					= (byte) 0xE2;
	public static final byte MSG_SET_WEIGHT 				= (byte) 0xE4;
	public static final byte MSG_SET_AGE 					= (byte) 0xE6;
	public static final byte MSG_SET_UOM 					= (byte) 0xE9;
}
